#ifndef YDAN_ROOM_4_H
#define YDAN_ROOM_4_H 1

extern SceneCmd ydan_room_4Commands[];
extern s16 ydan_room_4ObjectList_000040[];
extern ActorEntry ydan_room_4ActorEntry_000054[];
extern RoomShapeCullable ydan_room_4RoomShapeCullable_000120;
extern RoomShapeCullableEntry ydan_room_4RoomShapeCullableEntry_00012C[2];
extern s32 ydan_room_4_terminatorMaybe_00014C;
extern Vtx ydan_room_4Vtx_000150[];
extern Gfx ydan_room_4DL_001080[];
extern u64 ydan_room_4Tex_001920[];
extern u64 ydan_room_4Tex_002120[];
extern u64 ydan_room_4Tex_002920[];
extern u64 ydan_room_4Tex_003120[];
extern Vtx ydan_room_4Vtx_003920[];
extern Gfx ydan_room_4DL_003B20[];
extern u64 ydan_room_4Tex_003C28[];
#endif
