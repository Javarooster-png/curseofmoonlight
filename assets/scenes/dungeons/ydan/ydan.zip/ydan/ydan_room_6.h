#ifndef YDAN_ROOM_6_H
#define YDAN_ROOM_6_H 1

extern SceneCmd ydan_room_6Commands[];
extern s16 ydan_room_6ObjectList_000040[];
extern ActorEntry ydan_room_6ActorEntry_000058[];
extern RoomShapeCullable ydan_room_6RoomShapeCullable_000120;
extern RoomShapeCullableEntry ydan_room_6RoomShapeCullableEntry_00012C[1];
extern s32 ydan_room_6_terminatorMaybe_00013C;
extern Vtx ydan_room_6Vtx_000140[];
extern Gfx ydan_room_6DL_001430[];
extern u64 ydan_room_6Tex_001F00[];
extern u64 ydan_room_6Tex_002700[];
extern u64 ydan_room_6Tex_002F00[];
extern u64 ydan_room_6Tex_003700[];
extern u64 ydan_room_6Tex_003F00[];
extern u64 ydan_room_6Tex_004700[];
#endif
