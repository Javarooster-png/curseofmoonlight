#ifndef YDAN_ROOM_10_H
#define YDAN_ROOM_10_H 1

extern SceneCmd ydan_room_10Commands[];
extern s16 ydan_room_10ObjectList_000040[];
extern ActorEntry ydan_room_10ActorEntry_000054[];
extern RoomShapeCullable ydan_room_10RoomShapeCullable_0001B0;
extern RoomShapeCullableEntry ydan_room_10RoomShapeCullableEntry_0001BC[2];
extern s32 ydan_room_10_terminatorMaybe_0001DC;
extern Vtx ydan_room_10Vtx_0001E0[];
extern Gfx ydan_room_10DL_001370[];
extern u64 ydan_room_10Tex_001BE0[];
extern u64 ydan_room_10Tex_0023E0[];
extern u64 ydan_room_10Tex_002BE0[];
extern u64 ydan_room_10Tex_0033E0[];
extern Vtx ydan_room_10Vtx_003BE0[];
extern Gfx ydan_room_10DL_003D20[];
extern u64 ydan_room_10Tex_003DF8[];
#endif
