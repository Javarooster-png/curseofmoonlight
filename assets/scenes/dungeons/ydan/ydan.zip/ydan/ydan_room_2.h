#ifndef YDAN_ROOM_2_H
#define YDAN_ROOM_2_H 1

extern SceneCmd ydan_room_2Commands[];
extern s16 ydan_room_2ObjectList_000040[];
extern ActorEntry ydan_room_2ActorEntry_00005C[];
extern RoomShapeCullable ydan_room_2RoomShapeCullable_000200;
extern RoomShapeCullableEntry ydan_room_2RoomShapeCullableEntry_00020C[1];
extern s32 ydan_room_2_terminatorMaybe_00021C;
extern Vtx ydan_room_2Vtx_000220[];
extern Gfx ydan_room_2DL_001160[];
extern u64 ydan_room_2Tex_001D08[];
extern u64 ydan_room_2Tex_002508[];
extern u64 ydan_room_2Tex_002D08[];
extern u64 ydan_room_2Tex_003508[];
extern u64 ydan_room_2Tex_003D08[];
extern u64 ydan_room_2Tex_004508[];
extern Vtx ydan_room_2Vtx_004D10[];
extern Gfx ydan_room_2DL_004E50[];
extern u64 ydan_room_2Tex_004F28[];
#endif
