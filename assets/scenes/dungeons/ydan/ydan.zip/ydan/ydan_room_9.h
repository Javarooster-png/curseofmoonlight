#ifndef YDAN_ROOM_9_H
#define YDAN_ROOM_9_H 1

extern SceneCmd ydan_room_9Commands[];
extern s16 ydan_room_9ObjectList_000040[];
extern ActorEntry ydan_room_9ActorEntry_00005C[];
extern RoomShapeCullable ydan_room_9RoomShapeCullable_0000F0;
extern RoomShapeCullableEntry ydan_room_9RoomShapeCullableEntry_0000FC[5];
extern s32 ydan_room_9_terminatorMaybe_00014C;
extern Vtx ydan_room_9Vtx_000150[];
extern Gfx ydan_room_9DL_0013E0[];
extern Vtx ydan_room_9Vtx_001EC0[];
extern Gfx ydan_room_9DL_002290[];
extern u64 ydan_room_9Tex_002480[];
extern u64 ydan_room_9Tex_002C80[];
extern u64 ydan_room_9Tex_003480[];
extern u64 ydan_room_9Tex_003C80[];
extern u64 ydan_room_9Tex_004480[];
extern u64 ydan_room_9Tex_004C80[];
extern u64 ydan_room_9Tex_005480[];
extern u64 ydan_room_9Tex_005C80[];
extern u64 ydan_room_9Tex_006480[];
extern Vtx ydan_room_9Vtx_006C80[];
extern Gfx ydan_room_9DL_006EA0[];
extern Vtx ydan_room_9Vtx_007000[];
extern Gfx ydan_room_9DL_0070E0[];
extern Vtx ydan_room_9Vtx_0071F8[];
extern Gfx ydan_room_9DL_007368[];
extern u64 ydan_room_9Tex_007498[];
extern u64 ydan_room_9Tex_008498[];
extern u64 ydan_room_9Tex_008898[];
#endif
