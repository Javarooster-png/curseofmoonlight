#ifndef YDAN_ROOM_11_H
#define YDAN_ROOM_11_H 1

extern SceneCmd ydan_room_11Commands[];
extern s16 ydan_room_11ObjectList_000038[];
extern RoomShapeCullable ydan_room_11RoomShapeCullable_000050;
extern RoomShapeCullableEntry ydan_room_11RoomShapeCullableEntry_00005C[2];
extern s32 ydan_room_11_terminatorMaybe_00007C;
extern Vtx ydan_room_11Vtx_000080[];
extern Gfx ydan_room_11DL_002D90[];
extern u64 ydan_room_11Tex_003CD8[];
extern u64 ydan_room_11Tex_0044D8[];
extern u64 ydan_room_11Tex_0054D8[];
extern u64 ydan_room_11Tex_005CD8[];
extern Vtx ydan_room_11Vtx_0060E0[];
extern Gfx ydan_room_11DL_006730[];
extern u64 ydan_room_11Tex_006968[];
#endif
