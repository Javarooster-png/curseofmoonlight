#ifndef YDAN_ROOM_7_H
#define YDAN_ROOM_7_H 1

extern SceneCmd ydan_room_7Commands[];
extern s16 ydan_room_7ObjectList_000040[];
extern ActorEntry ydan_room_7ActorEntry_00005C[];
extern RoomShapeCullable ydan_room_7RoomShapeCullable_0002B0;
extern RoomShapeCullableEntry ydan_room_7RoomShapeCullableEntry_0002BC[2];
extern s32 ydan_room_7_terminatorMaybe_0002DC;
extern Vtx ydan_room_7Vtx_0002E0[];
extern Gfx ydan_room_7DL_001DE0[];
extern u64 ydan_room_7Tex_002C98[];
extern u64 ydan_room_7Tex_003498[];
extern u64 ydan_room_7Tex_003C98[];
extern u64 ydan_room_7Tex_004498[];
extern u64 ydan_room_7Tex_004C98[];
extern u64 ydan_room_7Tex_005498[];
extern u64 ydan_room_7Tex_005898[];
extern u64 ydan_room_7Tex_006098[];
extern u64 ydan_room_7Tex_006898[];
extern u64 ydan_room_7Tex_006C98[];
extern u64 ydan_room_7Tex_007098[];
extern Vtx ydan_room_7Vtx_0078A0[];
extern Gfx ydan_room_7DL_0079C0[];
extern u64 ydan_room_7Tex_007A98[];
#endif
