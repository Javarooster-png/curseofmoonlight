#ifndef YDAN_ROOM_1_H
#define YDAN_ROOM_1_H 1

extern SceneCmd ydan_room_1Commands[];
extern s16 ydan_room_1ObjectList_000040[];
extern ActorEntry ydan_room_1ActorEntry_000054[];
extern RoomShapeCullable ydan_room_1RoomShapeCullable_000120;
extern RoomShapeCullableEntry ydan_room_1RoomShapeCullableEntry_00012C[1];
extern s32 ydan_room_1_terminatorMaybe_00013C;
extern Vtx ydan_room_1Vtx_000140[];
extern Gfx ydan_room_1DL_000A40[];
extern u64 ydan_room_1Tex_000F98[];
extern u64 ydan_room_1Tex_001798[];
extern u64 ydan_room_1Tex_001F98[];
extern u64 ydan_room_1Tex_002798[];
extern Vtx ydan_room_1Vtx_002FA0[];
extern Gfx ydan_room_1DL_003110[];
extern u64 ydan_room_1Tex_003200[];
#endif
