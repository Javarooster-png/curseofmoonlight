#ifndef YDAN_ROOM_8_H
#define YDAN_ROOM_8_H 1

extern SceneCmd ydan_room_8Commands[];
extern s16 ydan_room_8ObjectList_000040[];
extern ActorEntry ydan_room_8ActorEntry_000054[];
extern RoomShapeCullable ydan_room_8RoomShapeCullable_000110;
extern RoomShapeCullableEntry ydan_room_8RoomShapeCullableEntry_00011C[1];
extern s32 ydan_room_8_terminatorMaybe_00012C;
extern Vtx ydan_room_8Vtx_000130[];
extern Gfx ydan_room_8DL_000760[];
extern u64 ydan_room_8Tex_000988[];
#endif
