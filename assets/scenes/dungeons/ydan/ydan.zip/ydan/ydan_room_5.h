#ifndef YDAN_ROOM_5_H
#define YDAN_ROOM_5_H 1

extern SceneCmd ydan_room_5Commands[];
extern s16 ydan_room_5ObjectList_000040[];
extern ActorEntry ydan_room_5ActorEntry_00005C[];
extern RoomShapeCullable ydan_room_5RoomShapeCullable_000180;
extern RoomShapeCullableEntry ydan_room_5RoomShapeCullableEntry_00018C[2];
extern s32 ydan_room_5_terminatorMaybe_0001AC;
extern Vtx ydan_room_5Vtx_0001B0[];
extern Gfx ydan_room_5DL_0022F0[];
extern Vtx ydan_room_5Vtx_003228[];
extern Gfx ydan_room_5DL_003C98[];
extern u64 ydan_room_5Tex_003F88[];
extern u64 ydan_room_5Tex_004788[];
extern u64 ydan_room_5Tex_004F88[];
extern u64 ydan_room_5Tex_005788[];
extern u64 ydan_room_5Tex_005B88[];
extern u64 ydan_room_5Tex_006388[];
extern u64 ydan_room_5Tex_006B88[];
extern u64 ydan_room_5Tex_006F88[];
extern u64 ydan_room_5Tex_007388[];
extern u64 ydan_room_5Tex_007788[];
extern u64 ydan_room_5Tex_007B88[];
#endif
